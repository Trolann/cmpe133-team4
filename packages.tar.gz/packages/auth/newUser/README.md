# DigitalOcean serverless function guide for Binge
1. Setup account on DigitalOcean
2. Give account name to Trevor for access
3. Setup local `.env` file (see discord for current version)
4. Install and configure `doctl` (for remote development of serverless functions)
5. # TODO: continue
6. setup create a new branch, make the function, test it locally if needed, create a requirements.txt, update 
   project.yml, deploy with doctl as serverless function until the output is right then merge your code to a new branch,
   close your PR, delete your old branches, close JIRA tickets (use JIRA tags for all development). Add links, etc.