fake_settings_json = {
    "nickname": "fake",
    "dark_mode": True,
    "language": "en",
    "vegan": False,
    "friends": [
        12345, 67890, 13579, 24680, 98765, 43210
    ]
}